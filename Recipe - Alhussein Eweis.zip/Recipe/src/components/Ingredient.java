package components;

public abstract class Ingredient 
{
	protected String description;
	
	public Ingredient(String description)
	{
		this.description = description;
	}
	
	public abstract void setDescription(String description);
	
	public String getDescription()
	{
		return description;
	}
}
