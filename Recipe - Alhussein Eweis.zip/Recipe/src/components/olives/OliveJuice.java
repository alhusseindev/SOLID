package components.olives;

import components.Ingredient;

public class OliveJuice extends Ingredient
{
	private static final String UNIT = "tbsp.";
	
	private Integer quantity;
	
	public OliveJuice(Integer quantity, String description)
	{
		super(String.format("%d %s %s", quantity, UNIT, description));
	}
	
	public void setQuantity(Integer quantity)
	{
		this.quantity = quantity;
	}
	
	public Integer getQuantity()
	{
		return quantity;
	}
	
	@Override
	public void setDescription(String description) 
	{
		this.description =
				String.format("%d %s %s", quantity, UNIT, description);
	}

}
