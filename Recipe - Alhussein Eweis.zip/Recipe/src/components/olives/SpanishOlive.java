package components.olives;

public class SpanishOlive extends Olive
{
	private String stuffing;
	
	public SpanishOlive(String description, String stuffing)
	{
		super(String.format("%s stuffed %s", stuffing, description));
		this.stuffing = stuffing;
	}

	public void setStuffing(String stuffing)
	{
		this.stuffing = stuffing;
	}
	
	public String getStuffing()
	{
		return stuffing;
	}

}
