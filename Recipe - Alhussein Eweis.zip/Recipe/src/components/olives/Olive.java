package components.olives;

import components.Ingredient;

public abstract class Olive extends Ingredient
{
	private boolean pitted;
	
	public Olive(String description)
	{
		super(description);
	}

	@Override
	public void setDescription(String description)
	{
		this.description = description;
	}
	
	public void setPitted(boolean pitted)
	{
		this.pitted = pitted;
	}
	
	public boolean isPitted()
	{
		return pitted;
	}
}
