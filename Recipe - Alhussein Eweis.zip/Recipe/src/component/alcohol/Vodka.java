package component.alcohol;

import components.Ingredient;

public class Vodka extends Ingredient
{
	private static final String UNIT = "oz.";
	private Integer quantity;
	
	public Vodka(Integer quantity, String description)
	{
		super(String.format("%s %s %s", quantity, UNIT, description));
		this.quantity = quantity;
	}
	
	public void setQuantity(Integer quantity)
	{
		this.quantity = quantity;
	}
	
	public Integer getQuantity()
	{
		return quantity;
	}

	@Override
	public void setDescription(String description) 
	{
		this.description = 
				String.format("%s ounces of %s", quantity, description);
	}

}
