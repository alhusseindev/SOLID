package main;

import java.util.ArrayList;
import java.util.List;

import component.alcohol.Vodka;
import components.Ingredient;
import components.olives.OliveJuice;
import components.olives.SpanishOlive;

public class Recipe 
{
	private String title;
	private List<Ingredient> list =
			new ArrayList<Ingredient>();
	
	public final SpanishOlive mySpOlive;
	public final OliveJuice myOJuice;
	public final Vodka myVodka;
	
	public Recipe(String title)
	{
		this.title = title;
		//Note: that we are instantiating the objects in the constructor
		mySpOlive = new SpanishOlive("Large Spanish Olive", "Pimento");
		myOJuice = new OliveJuice (2, "Tasty Olive Juice");
		myVodka = new Vodka(4, "Fine Vodka");
	}
	
	public void addIngredient(Ingredient ingredient)
	{
		list.add(ingredient);
	}
	
	public void print()
	{
		StringBuffer buffer = new StringBuffer();
		
		buffer.append(title)
			.append(System.lineSeparator())
					.append(System.lineSeparator());
		list.forEach(ingredient -> 
			buffer.append(ingredient.getDescription())
				.append(System.lineSeparator()));
		System.out.println(buffer.toString());
	}
	
	public static void main(String[] args)
	{
		Recipe recipe = new Recipe("Vodka Martini");
		
		// TODO : Create a Recipe by adding
		//        ingredients.
		recipe.addIngredient("Lemonade");
		recipe.addIngredient("Grapes");
		recipe.addIngredient("Cherries");
	
		
		// TODO : You will need to create the
		//        ingredients similar to the below
		//        example.
		//        Be sure to keep in mind SOLID!
		
		// Here's an example ...
		SpanishOlive spanishOlive = new SpanishOlive("Large Spanish Olive", "Pimento");
		OliveJuice oliveJuice = new OliveJuice (2, "Tasty Olive Juice");
		Vodka vodka = new Vodka(4, "Fine Vodka");
		
		recipe.addIngredient(spanishOlive);
		recipe.addIngredient(oliveJuice);
		recipe.addIngredient(vodka);
		
		
		recipe.print();
		
		
		/** objects are instantiated in the constructor of the recipe class */
		
		
		recipe.addIngredient(mySpOlive);
		recipe.addIngredient(myOJuice);
		recipe.addIngredient(myVodka);
		
		
		recipe.print();
	}

}
