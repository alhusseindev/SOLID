package edu.rutgers.account;

public final class GoldCheckingAccount extends Account
{	
	public GoldCheckingAccount()
	{
		super();
		applyBonus();
	}
	
	public GoldCheckingAccount(double deposit)
	{
		super(deposit);
		applyBonus();
	}
	
	private void applyBonus()
	{
		balance = balance + 50;
	}
	
}
