package edu.rutgers.account;

public final class CheckingAccount extends Account
{
	public CheckingAccount()
	{
		super();
	}
}
