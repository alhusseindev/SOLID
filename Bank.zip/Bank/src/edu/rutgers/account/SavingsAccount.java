package edu.rutgers.account;

import edu.rutgers.account.exception.DepositException;

public class SavingsAccount extends Account
{
	private static final double DEPOSIT_MODIFIER = 0.10;
	
	public SavingsAccount()
	{
		super();
	}
	
	public SavingsAccount(double balance)
	{
		super(balance);
	}
	
	private double applyBonus(double amount)
	{
		return (amount + (amount * DEPOSIT_MODIFIER));
	}
	
	@Override
	public void deposit(double amount) throws DepositException
	{
		if (amount > 500.0)
		{
			super.deposit(applyBonus(amount));
		}		
		else if (amount > 0.0)
		{
			super.deposit(amount);
		}
		else
		{
			throw new DepositException("Deposit amount must be greater than zero.");
		}
	}
}
