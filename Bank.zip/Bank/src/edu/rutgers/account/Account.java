package edu.rutgers.account;

import edu.rutgers.account.exception.DepositException;

public abstract class Account 
{
	// TODO : Java Assignment
	//      : Choose one of the two options below to extend the Account class.
	
	//      : 1. Require a minimum balance of $50 to open an account.
	//      : 2. Add a withdraw method.
	//      : 3. DONE - Give a 10% bonus for every Savings deposit over $500.

	// TODO : The protected method applyBonus() does not belong here because
	//        it can be overridden by extension of Account.  Modify the
	//        GoldCheckingAccount class to implement applyBonus() and also
	//        prevent it from maliciously being modified.
	//        Note: If you've done this correctly, MaliciousAccount will
	//              not compile.
	private static final double DEFAULT_BALANCE = 0.0;
	
	protected double balance;
	
	public Account(double balance)
	{
		this.balance = balance;
	}
	
	public Account()
	{
		this(DEFAULT_BALANCE);
	}
	
	public void deposit(double amount) throws DepositException 
	{
		if (amount > 0.0)
		{
			balance = balance + amount;
		}
		else
		{
			throw new DepositException("Deposit amount must be greater than zero.");
		}
	}
	
	public double getBalance() 
	{
		return balance;
	}	
}

