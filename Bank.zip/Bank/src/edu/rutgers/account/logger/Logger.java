package edu.rutgers.account.logger;

public abstract class Logger 
{
	public abstract void log(String buffer);
}
