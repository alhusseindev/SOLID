package edu.rutgers.account.logger;

public class ConsoleLogger extends Logger
{
	@Override
	public void log(String buffer)
	{
		System.out.println(buffer);
	}
}
