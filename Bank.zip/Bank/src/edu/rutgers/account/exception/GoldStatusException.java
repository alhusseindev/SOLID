package edu.rutgers.account.exception;

public class GoldStatusException extends Exception
{
	private static final long serialVersionUID = -4259367910446134699L;

	public GoldStatusException(String errorMessage)
	{
		super(errorMessage);
	}
}
