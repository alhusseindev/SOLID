package edu.rutgers.account.exception;

public class DepositException extends Exception 
{
	private static final long serialVersionUID = 6841097112211003163L;

	public DepositException(String errorMessage)
	{
		super(errorMessage);
	}
}
