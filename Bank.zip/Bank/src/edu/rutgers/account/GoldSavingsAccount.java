package edu.rutgers.account;

public final class GoldSavingsAccount extends SavingsAccount
{
	private final static double GOLD_BONUS = 50.0;
	
	public GoldSavingsAccount(double balance)
	{
		super(balance + GOLD_BONUS);
	}
}
