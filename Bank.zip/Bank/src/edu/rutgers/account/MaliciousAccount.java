package edu.rutgers.account;

//public class MaliciousAccount extends GoldCheckingAccount
//{
//	public MaliciousAccount(double balance)
//	{
//		super(balance);
//	}
//	
//	@Override
//	protected void applyBonus()
//	{
//		balance = balance + 1000000.0;
//	}
//}
