package edu.rutgers.customer;

import edu.rutgers.account.Account;
import edu.rutgers.account.CheckingAccount;
import edu.rutgers.account.GoldCheckingAccount;
import edu.rutgers.account.GoldSavingsAccount;
//import edu.rutgers.account.MaliciousAccount;
import edu.rutgers.account.SavingsAccount;
import edu.rutgers.account.exception.DepositException;
import edu.rutgers.account.exception.GoldStatusException;
import edu.rutgers.account.logger.Logger;

public class Customer 
{
	private static final String GOLD_SAVINGS_STATUS_MESSAGE =
			"%s is a Gold Savings Account holder.";
			
	private static final String SUMMARY =
			"Account Summary\n" +
			"--------------------------------------\n" +
			"Name                  : %s\n" +
			"Checking Balance      : $%.2f\n" +
			"Savings Balance       : $%.2f\n" +
			"Gold Checking Balance : $%.2f";
	
	private Logger logger;
	
	private String name;
	private Account checking;
	private Account savings;
	private Account goldChecking;
	
	public Customer(Logger logger)
	{
		this.logger = logger;
	}
	
	public void setup(String name)
	{
		this.name = name;
		
		checking = new CheckingAccount();
		savings = new SavingsAccount();
		goldChecking = new GoldCheckingAccount();
	}

	public void depositChecking(double amount) throws DepositException
	{
		checking.deposit(amount);
	}
	
	public void depositSavings(double amount) throws DepositException
	{
		savings.deposit(amount);
	}

	public void depositGoldChecking(double amount) throws DepositException
	{
		goldChecking.deposit(amount);
	}
	
	public void verifyGoldSavingsStatus(double threshold) throws GoldStatusException
	{
		if (savings instanceof GoldSavingsAccount && getSavingsBalance() > threshold)
		{
			throw new GoldStatusException(String.format(GOLD_SAVINGS_STATUS_MESSAGE, name));
		}
	}
	
	public void upgradeSavingsAcount()
	{
		double balance = savings.getBalance();
		savings = new GoldSavingsAccount(balance);
	}
	
	public double getCheckingBalance()
	{
		return checking.getBalance();
	}
	
	public double getSavingsBalance()
	{
		return savings.getBalance();
	}
	
	public double getGoldCheckingBalance()
	{
		return goldChecking.getBalance();
	}
	
	public void showAccountSummary()
	{
		logger.log(String.format(SUMMARY, name, getCheckingBalance(), getSavingsBalance(), getGoldCheckingBalance()));
	}
}