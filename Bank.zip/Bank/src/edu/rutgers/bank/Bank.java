package edu.rutgers.bank;

import edu.rutgers.account.exception.DepositException;
import edu.rutgers.account.exception.GoldStatusException;
import edu.rutgers.account.logger.ConsoleLogger;
import edu.rutgers.account.logger.Logger;
import edu.rutgers.customer.Customer;

public class Bank 
{
	private static final double GOLD_STATUS_THRESHOLD = 1000.0;
	
	private static final String GOLD_CHECKING_MESSAGE = "Gold Checking ";
	
	private static final String CHECKING_MESSAGE = "Checking ";
	
	private static final String SAVINGS_MESSAGE = "Savings ";
	
	private static final String WELCOME_MESSAGE =
			"Bank of Secure Coding v.1.0";
	
	private static final String DEPOSIT_ERROR_MESSAGE =
			"Deposit Amount $%.2f : %s";
	
	private static final String CHECKING_DEPOSIT_ERROR_MESSAGE =
			CHECKING_MESSAGE + DEPOSIT_ERROR_MESSAGE;

	private static final String GOLD_CHECKING_DEPOSIT_ERROR_MESSAGE =
			GOLD_CHECKING_MESSAGE + DEPOSIT_ERROR_MESSAGE;
	
	private static final String SAVINGS_DEPOSIT_ERROR_MESSAGE =
			SAVINGS_MESSAGE + DEPOSIT_ERROR_MESSAGE;
	
	private static final String DEPOSIT_MESSAGE =
			"Deposit : $%.2f";
	
	private static final String GOLD_CHECKING_DEPOSIT_MESSAGE =
			GOLD_CHECKING_MESSAGE + DEPOSIT_MESSAGE;
	
	private static final String CHECKING_DEPOSIT_MESSAGE =
			CHECKING_MESSAGE + DEPOSIT_MESSAGE;
	
	private static final String SAVINGS_DEPOSIT_MESSAGE = 
			SAVINGS_MESSAGE + DEPOSIT_MESSAGE;

	private Logger logger;
	private Customer customer;
	
	public Bank(Logger logger)
	{
		this.logger = logger;
	}
	
	public void addCustomer(String name)
	{
		customer = new Customer(logger);
		customer.setup(name);
	}
	
	public void depositChecking(double amount)
	{
		try 
		{
			logger.log(String.format(CHECKING_DEPOSIT_MESSAGE, amount));
			customer.depositChecking(amount);
		}
		catch (DepositException e) 
		{
			logger.log(String.format(CHECKING_DEPOSIT_ERROR_MESSAGE, amount, e.getMessage()));
		}
	}

	public void depositGoldChecking(double amount)
	{
		try 
		{
			logger.log(String.format(GOLD_CHECKING_DEPOSIT_MESSAGE, amount));
			customer.depositGoldChecking(amount);
		}
		catch (DepositException e) 
		{
			logger.log(String.format(GOLD_CHECKING_DEPOSIT_ERROR_MESSAGE, amount, e.getMessage()));
		}
	}
	
	public void depositSavings(double amount)
	{
		try 
		{
			logger.log(String.format(SAVINGS_DEPOSIT_MESSAGE, amount));
			
			customer.depositSavings(amount);
	
			customer.verifyGoldSavingsStatus(GOLD_STATUS_THRESHOLD);
			
			customer.upgradeSavingsAcount();
		} 
		catch (DepositException e) 
		{
			logger.log(String.format(SAVINGS_DEPOSIT_ERROR_MESSAGE, amount, e.getMessage()));
		} 
		catch (GoldStatusException e) 
		{
			logger.log(e.getMessage());
		}
	}
	
	public void showCustomerSummary()
	{
		customer.showAccountSummary();
	}
	
	public void showWelcomeMessage()
	{
		logger.log(WELCOME_MESSAGE);
	}
	
	public static void main(String[] args) 
	{
		Bank bank = new Bank(new ConsoleLogger());

		bank.showWelcomeMessage();
		bank.addCustomer("Joe");
		
		bank.depositChecking(100);
		
		bank.depositChecking(-2);
		
		bank.depositGoldChecking(100);

		bank.depositSavings(200);
		bank.depositSavings(1000);
		bank.depositSavings(500);
		
		
		
		bank.showCustomerSummary();
	
	}
}
